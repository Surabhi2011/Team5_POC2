package WebPages;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
public class TestNG2 extends TestNG1{
	Login login;
	MyAccount account;
	Read_Excel ex;
	String[][] data;
	WebDriverWait wt;
	@DataProvider(name="GetData")
	public String[][] Data(){
		ex=new Read_Excel();
		String[][] data=ex.read();
		return data;
	}
	@Test(priority=4)
	public void testLoginlogin() {
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		
		login = new Login(dr);
		//wt.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")));

		String actual = login.get_Title();
		String expected = "Demo Web Shop. Login";
		SoftAssert s=new SoftAssert();
		s.assertEquals(actual, expected);
		//log=Logger.getLogger("devpinoyLogger");
		log.info("==========================================================================================================");
		log.info("Test Case _ Verify Login Title");
		log.info("==========================================================================================================");
		log.info("Expected : "+expected);
		log.info("Actual : "+actual);
		log.info("Test Result : Pass");
}
	@Test(priority=5,dataProvider="GetData")
	public void testMyAccount(String Id, String Pass,String Exp) {
		login.dologin(Id,Pass);
        account=new MyAccount(dr);
        if(login.error().contains("False")){
        String actual=account.get_email();
        String expected=Exp;
        if(actual.contains(expected)) {
        //log.info("\n==================================================================");
        	log.info("==========================================================================================================");
    		log.info("Test Case _ Verify Login ");
    		log.info("==========================================================================================================");
    		log.info("Expected : "+expected);
    		log.info("Actual : "+actual);
    		log.info("Test Result : Pass");

        }        else {
        	log.info("==========================================================================================================");
    		log.info("Test Case _ Verify Login");
    		log.info("==========================================================================================================");
    		log.info("Expected : "+expected);
    		log.info("Actual : "+actual);
    		log.info("Test Result : Fail");

        }
		account.logout();
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();}
        else {
        	 String actual=login.error();
        	 String expected=Exp;
             if(actual.contains(expected)) {
             //log.info("\n==================================================================");
            	 log.info("==========================================================================================================");
         		log.info("Test Case _ Verify Login ");
         		log.info("==========================================================================================================");
         		log.info("Expected : "+expected);
         		log.info("Actual : "+actual);
         		log.info("Test Result : Pass");
}
             else {
            	 log.info("==========================================================================================================");
         		log.info("Test Case _ Verify Login");
         		log.info("==========================================================================================================");
         		log.info("Expected : "+expected);
         		log.info("Actual : "+actual);
         		log.info("Test Result : Fail");
;
             }
     		account.logout();
     		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();}
        }
}

