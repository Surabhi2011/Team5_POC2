package WebPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MyAccount {
	@FindBy(xpath="/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")
	WebElement id;
	WebDriver dr;

	public MyAccount(WebDriver dr) {
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}

	public String get_Title() {
		return dr.getTitle();
	}

	public String get_email() {
		return id.getText();
	}
	public void logout() {
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();;
	}
	
}
