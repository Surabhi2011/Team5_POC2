package WebPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login {
	@FindBy(xpath="//*[@id=\"Email\"]")
	WebElement uname;
	WebElement Register;
	@FindBy(xpath="//*[@id=\"Password\"]")
	WebElement pwd;
	@FindBy(xpath="/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")
	WebElement btn;
    @FindBy(xpath="/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div")
    WebElement err;
	WebDriver dr;
    String error;
	public Login(WebDriver dr) {
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}
    public String get_Title() {
    	return dr.getTitle();
    }
	public void set_uname(String un) {
		uname.sendKeys(un);
	}

	public void set_pwd(String pword) {
		pwd.sendKeys(pword);
	}

	public void doclick() {
		btn.click();
	}

	public void dologin(String u, String p) {
		this.set_uname(u);
		this.set_pwd(p);
		this.doclick();
	}
	public String error() {
		error="False";
		try {
		if(err.isDisplayed()) {
			error=err.getText();
		}}
		catch(Exception e) {
			error="False";
		}
		return error;
	}

	
}
